# !/usr/bin/env python
# -*- coding:utf-8 -*-


def main():
    print('hello')
    
if __name__ == '__main__':
    main()